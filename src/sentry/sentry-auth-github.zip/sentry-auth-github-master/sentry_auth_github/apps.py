from __future__ import absolute_import

from django.apps import AppConfig


class Config(AppConfig):
    name = "sentry_auth_github"

    def ready(self):
        from sentry.auth import register

        from .provider import GitHubOAuth2Provider

        register('github', GitHubOAuth2Provider)

from __future__ import absolute_import

from .manager import ExperimentManager

manager = ExperimentManager()

all = manager.all

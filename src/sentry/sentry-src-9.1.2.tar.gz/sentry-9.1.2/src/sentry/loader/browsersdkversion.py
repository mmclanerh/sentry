from __future__ import absolute_import

import os
import re
import logging
import json
import six

from pkg_resources import parse_version
from functools32 import lru_cache

import sentry

from django.conf import settings

logger = logging.getLogger('sentry')

_version_regexp = re.compile(r'^\d+\.\d+\.\d+$')  # We really only want stable releases
LOADER_FOLDER = os.path.abspath(os.path.join(os.path.dirname(sentry.__file__), 'loader'))
DEFAULT_VERSION = '4.x'  # DEFAULT_VERSION must exists, in case of 5.0 a new constant should be introduced


@lru_cache(maxsize=10)
def load_registry(path):
    if '/' in path:
        return None
    fn = os.path.join(LOADER_FOLDER, path + '.json')
    try:
        with open(fn, 'rb') as f:
            return json.load(f)
    except IOError:
        return None


def get_highest_browser_sdk_version(versions):
    full_versions = filter(lambda x: _version_regexp.match(x), versions)
    return six.binary_type(max(map(parse_version, full_versions))
                           ) if full_versions else settings.JS_SDK_LOADER_SDK_VERSION


def get_browser_sdk_version_versions():
    return ['latest', DEFAULT_VERSION]


def get_browser_sdk_version_choices():
    rv = []
    for version in get_browser_sdk_version_versions():
        rv.append((version, version))
    return tuple(rv)


def load_version_from_file():
    data = load_registry('_registry')
    if data:
        return data.get('versions', [])
    return []


def get_highest_selected_browser_sdk_version(selected_version):
    versions = load_version_from_file()
    if selected_version == 'latest':
        return get_highest_browser_sdk_version(versions)
    return get_highest_browser_sdk_version(
        filter(lambda x: x.startswith(selected_version[0]), versions))


def get_browser_sdk_version(project_key):
    selected_version = get_selected_browser_sdk_version(project_key)

    try:
        return get_highest_selected_browser_sdk_version(selected_version)
    except BaseException:
        logger.error('error ocurred while trying to read js sdk information from the registry')
        return settings.JS_SDK_LOADER_SDK_VERSION


def get_selected_browser_sdk_version(project_key):
    return project_key.data.get('browserSdkVersion', DEFAULT_VERSION)

import styled from 'react-emotion';

const ConfirmHeader = styled.div`
  font-size: 1.2em;
  margin-bottom: 10px;
`;

export default ConfirmHeader;

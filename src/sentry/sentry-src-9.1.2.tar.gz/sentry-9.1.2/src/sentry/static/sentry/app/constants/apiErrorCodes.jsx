export const SUDO_REQUIRED = 'sudo-required';
export const SUPERUSER_REQUIRED = 'superuser-required';
export const PROJECT_MOVED = 'project-moved';

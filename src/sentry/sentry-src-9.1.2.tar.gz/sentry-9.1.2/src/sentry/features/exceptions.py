from __future__ import absolute_import

__all__ = ['FeatureNotRegistered']


class FeatureNotRegistered(Exception):
    def __init__(self, name):
        msg = (
            u'The "{}" feature has not been registered. '
            'Ensure that a feature has been added to sentry.features.default_manager')
        super(Exception, self).__init__(msg.format(name))
